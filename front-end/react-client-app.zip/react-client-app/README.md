After cloning


'npm install'

'npm run dev'

 Local:   [http://localhost:5173/](http://localhost:5173/)