import { createBrowserRouter } from "react-router";
import routes from "./routes.tsx";

const router= createBrowserRouter(routes);

export default router
